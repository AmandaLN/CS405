// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <exception>

// Define a custom exception derived from std::exception (or std::runtime_error)
class CustomApplicationException : public std::runtime_error {
public:
    // Pass custom error message to std::runtime_error base class
    explicit CustomApplicationException(const std::string& message)
        : std::runtime_error(message) {}
};

bool do_even_more_custom_application_logic()
{
    // Throw any standard exception
    // Throwing std::out_of_range to simulate an out-of-bounds error condition
    throw std::out_of_range("Standard Exception: Out of range error in do_even_more_custom_application_logic()");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cout << "[Caught std::exception in do_custom_application_logic]: " << e.what() << std::endl;
        std::cout << "Continuing execution after handling exception..." << std::endl;
    }

    // Throw a custom exception derived from std::exception
    //  and catch it explicitly in main
    throw CustomApplicationException("Custom Exception: Critical error occurred in do_custom_application_logic()");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f) {
        throw std::invalid_argument("Standard Exception: Division by zero attempted in divide()");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0.0f;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "[Caught Specific Exception in do_division]: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomApplicationException& e) {
        std::cout << "[Caught Custom Exception in main]: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "[Caught std::exception in main]: " << e.what() << std::endl;
    }
    catch (...) {
        std::cout << "[Caught Unknown Exception in main]: An uncaught exception was captured." << std::endl;
    }

    std::cout << "Program completed successfully without crashing!" << std::endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu